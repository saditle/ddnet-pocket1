# DDNet Pocket — Мобильное приложение для Android (Карты, Игроки, Ранги и Серверы ddnet.org)

В этом архиве находится готовый проект Android-приложения (`ru.ddnet.companion`) со встроенным интерфейсом `DDNet Pocket` и нативным Java-мостом `DDNetNativeBridge` для прямых запросов к JSON API сайта `ddnet.org` без браузерных ограничений CORS.

## Как получить готовый установочный файл `.apk` (2 простых способа)

### Способ 1. Автосборка в облаке через GitHub Actions (без установки Android Studio, можно даже с телефона!)
1. Создайте бесплатный репозиторий на [GitHub](https://github.com/new) и загрузите туда файлы из этого архива (папки `app`, `gradle`, `.github`, файлы `build.gradle`, `settings.gradle`, `gradle.properties`).
2. Перейдите во вкладку **Actions** в вашем репозитории — workflow `Build DDNet Pocket Android APK` запустится автоматически.
3. Через ~1.5 минуты скачайте готовый файл **`ddnet-pocket-debug-apk`** в разделе **Artifacts** и установите `.apk` на телефон!

### Способ 2. Сборка в Android Studio на ПК
1. Распакуйте архив и откройте папку в **Android Studio**.
2. В верхнем меню выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Готовый файл появится по пути `app/build/outputs/apk/debug/app-debug.apk`.

### Способ 3. Мгновенная установка без сборки (PWA)
Вы также можете открыть файл `app/src/main/assets/index.html` (или прикреплённый в чате `ddnet_mobile_app.html`) в браузере Chrome на телефоне и нажать **«Добавить на главный экран»**.
